/* FINOTAM Bridge v4
   Connects the legacy FINOTAM/Blogfa assessment to the new Financing Engines app.
   Safe by default: full profile is shared only through same-origin localStorage.
   Cross-origin fallback passes only non-sensitive starter fields in the URL.
*/
(function (window, document) {
  'use strict';

  var PROFILE_KEY = 'FINOTAM_PROFILE_V4';
  var RESULT_KEY = 'FINOTAM_ENGINE_RESULTS_V4';
  var ENGINE_PAGE = 'financing-engines.html';

  function byId(id) { return document.getElementById(id); }
  function value(id) {
    var el = byId(id);
    return el ? String(el.value || '').trim() : '';
  }
  function num(id) {
    var v = value(id).replace(/,/g, '');
    var n = Number(v);
    return isFinite(n) ? n : 0;
  }
  function checkedPurposes() {
    return Array.prototype.slice.call(document.querySelectorAll('input[name="purpose"]:checked'))
      .map(function (x) { return x.value; });
  }

  function buildProfile() {
    return {
      schema: 'FINOTAM_PROFILE_V4',
      version: 4,
      savedAt: new Date().toISOString(),
      source: 'legacy-assessment',
      unit: 'billion-IRR',
      company: {
        name: value('company') || value('quickCompany'),
        nationalId: value('nid'),
        type: value('ctype'),
        startYear: num('year'),
        registrationNo: value('regNo'),
        status: value('companyStatus')
      },
      need: {
        amount: num('need') || num('quickNeed'),
        purposes: checkedPurposes().length ? checkedPurposes() : (value('quickPurpose') ? [value('quickPurpose')] : []),
        urgency: value('urgency'),
        preference: value('structure'),
        term: value('term')
      },
      financials: {
        sales: num('sales'),
        profit: num('profit'),
        assets: num('assets'),
        liabilities: num('liabilities'),
        bankDebt: num('bankDebt'),
        receivables: num('receivables'),
        inventory: num('inventory')
      },
      eligibility: {
        contract: value('contract') === '1',
        statements: value('statements'),
        audit: value('audit') === '1',
        bankNeed: value('bankNeed') === '1',
        exporter: value('exporter') === '1',
        knowledgeBased: value('kb') === '1',
        guaranteeNeed: value('guarantee') === '1',
        investorNeed: value('investor') === '1',
        section141: value('section141'),
        overdueDebt: value('overdueDebt'),
        taxDebt: value('taxDebt'),
        bouncedCheck: value('bouncedCheck')
      },
      project: {
        rdSpend: num('rdSpend'),
        investmentDone: num('investmentDone'),
        eligibleReceivables: num('eligibleReceivables'),
        collateralValue: num('collateralValue'),
        guaranteeAmount: num('guaranteeAmount')
      },
      contact: {
        mobile: value('contactMobile'),
        role: value('contactRole')
      }
    };
  }

  function saveProfile(profile) {
    try {
      localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
      return true;
    } catch (e) {
      return false;
    }
  }

  function readProfile() {
    try {
      var raw = localStorage.getItem(PROFILE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function saveEngineResults(results) {
    try {
      localStorage.setItem(RESULT_KEY, JSON.stringify({
        schema: RESULT_KEY,
        savedAt: new Date().toISOString(),
        results: results || {}
      }));
    } catch (e) {}
  }

  function readEngineResults() {
    try {
      var raw = localStorage.getItem(RESULT_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function navigateToEngines() {
    var profile = buildProfile();
    saveProfile(profile);

    // Same-origin path: full profile stays in localStorage.
    // Cross-origin fallback: only starter/non-sensitive fields go in the URL.
    var target = ENGINE_PAGE;
    try {
      var here = new URL(window.location.href);
      var destination = new URL(ENGINE_PAGE, window.location.href);
      if (here.origin === destination.origin) {
        window.location.href = destination.href;
        return;
      }
    } catch (e) {}

    var params = new URLSearchParams();
    params.set('company', profile.company.name || '');
    params.set('need', String(profile.need.amount || ''));
    params.set('purpose', (profile.need.purposes[0] || ''));
    window.location.href = target + '?' + params.toString();
  }

  function attachEngineLinks() {
    var links = document.querySelectorAll('[data-finotam-engines], a[href="#financing-engines"]');
    Array.prototype.forEach.call(links, function (node) {
      node.addEventListener('click', function (e) {
        e.preventDefault();
        navigateToEngines();
      });
    });
  }

  // Public bridge API used by financing-engines.html and future engine modules.
  window.FinotamBridge = {
    PROFILE_KEY: PROFILE_KEY,
    RESULT_KEY: RESULT_KEY,
    buildProfile: buildProfile,
    saveProfile: saveProfile,
    readProfile: readProfile,
    saveEngineResults: saveEngineResults,
    readEngineResults: readEngineResults,
    goToEngines: navigateToEngines
  };

  document.addEventListener('DOMContentLoaded', attachEngineLinks);
})(window, document);
